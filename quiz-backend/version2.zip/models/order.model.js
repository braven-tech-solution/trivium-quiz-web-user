const mongoose = require("mongoose");
const { ObjectId } = mongoose.Schema.Types;
const validator = require("validator");

const orderSchema = mongoose.Schema(
  {
    id: {
      type: String,
      required: true,
    },

    items: [
      {
        productId: {
          type: ObjectId, // products Id
          required: true,
          ref: "Product",
        },
        price: {
          type: Number,
          required: true,
        },

        quantity: {
          type: Number,
          required: true,
        },
      },
    ],
    totalPrice: {
      type: Number,
      required: true,
    },
    orderStatus: {
      type: String,
      enum: ["pending", "confirmed", "shipped", "delivered"],
      default: "pending",
    },
    paymentMethod: {
      type: String,
      enum: ["credit_card", "paypal", "cash on delivery", "bkash"],
      default: "cash on delivery",
    },
    paymentStatus: {
      type: String,
      enum: ["pending", "completed", "failed"],
      default: "pending",
    },
    paymentInfo: {
      bkashNo: {
        type: String,
      },
      transactionId: {
        type: String,
      },
    },

    shippingAddress: { type: String, required: true },
    orderedBy: {
      name: {
        type: String,
        required: true,
      },
      id: {
        type: ObjectId,
        required: true,
        ref: "User",
      },
    },
  },
  {
    timestamps: true,
  }
);

const Order = mongoose.model("Order", orderSchema);

module.exports = Order;
